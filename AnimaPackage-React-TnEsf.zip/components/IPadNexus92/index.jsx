import React from "react";
import { Link } from "react-router-dom";
import "./IPadNexus92.css";

function IPadNexus92() {
  return (
    <div class="container-center-horizontal">
      <div className="ipad-nexus-9-2 screen">
        <Link to="/ipad-nexus-9-1">
          <div className="x768-purple-retangle border-1px-dove-gray"></div>
        </Link>
      </div>
    </div>
  );
}

export default IPadNexus92;
