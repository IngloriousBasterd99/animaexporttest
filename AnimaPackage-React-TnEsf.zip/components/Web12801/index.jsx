import React from "react";
import { Link } from "react-router-dom";
import "./Web12801.css";

function Web12801() {
  return (
    <div class="container-center-horizontal">
      <div className="web-1280-1 screen">
        <div className="flex-col">
          <div className="x1280-rectangle1 border-1px-dove-gray"></div>
          <div className="x1280-rectangle3 border-1px-dove-gray"></div>
        </div>
        <Link to="/web-1280-2">
          <div className="x1280-rectangle5 border-1px-dove-gray"></div>
        </Link>
        <div className="flex-col-1">
          <div className="x1280-rectangle2 border-1px-dove-gray"></div>
          <div className="x1280-rectangle4 border-1px-dove-gray"></div>
        </div>
      </div>
    </div>
  );
}

export default Web12801;
