import React from "react";
import { Link } from "react-router-dom";
import "./Web12802.css";

function Web12802() {
  return (
    <div class="container-center-horizontal">
      <div className="web-1280-2 screen">
        <Link to="/web-1280-1">
          <div className="x1280-purple-retangle border-1px-dove-gray"></div>
        </Link>
      </div>
    </div>
  );
}

export default Web12802;
