import "./App.css";
import React from "react";
import { Switch, BrowserRouter as Router, Route } from "react-router-dom";
import Web12801 from "./components/Web12801";
import Web12802 from "./components/Web12802";
import IPadNexus91 from "./components/IPadNexus91";
import IPadNexus92 from "./components/IPadNexus92";
import IPhone678SE1 from "./components/IPhone678SE1";
import IPhone678SE2 from "./components/IPhone678SE2";

function App() {
  return (
    <Router>
      <Switch>
        <Route path="/:path(|web-1280-1)">
          <Web12801>1280</Web12801>
        </Route>
        <Route path="/web-1280-2">
          <Web12802>1280</Web12802>
        </Route>
        <Route path="/ipad-nexus-9-1">
          <IPadNexus91>768</IPadNexus91>
        </Route>
        <Route path="/ipad-nexus-9-2">
          <IPadNexus92>768</IPadNexus92>
        </Route>
        <Route path="/iphone-6-7-8-se-1">
          <IPhone678SE1>375</IPhone678SE1>
        </Route>
        <Route path="/iphone-6-7-8-se-2">
          <IPhone678SE2>375</IPhone678SE2>
        </Route>
      </Switch>
    </Router>
  );
}

export default App;
